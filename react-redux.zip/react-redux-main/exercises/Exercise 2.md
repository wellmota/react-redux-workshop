# Exercise 2

Create an action to delete items from the "Done" list.

With the action created, use it on the DoneList component to remove items from the list.

## Tips
- The `deleteItem` function on the `DoneList` component is already receiving the index as a parameter
- Array function `Splice` can be used to remove the item from the Todos list